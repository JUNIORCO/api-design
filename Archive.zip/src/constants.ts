export const baseURL = 'https://api.hatchways.io';
export const postsURL = '/assessment/blog/posts';

export const DEFAULT_SORTBY = 'id';
export const DEFAULT_DIRECTION = 'asc';

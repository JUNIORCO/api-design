export const INVALID_TAGS = 'Tags parameter is required';
export const INVALID_SORTBY = 'sortBy parameter is invalid';
export const INVALID_DIRECTION = 'direction parameter is invalid';
